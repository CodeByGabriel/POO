import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;

public class PacienteController {

    @FXML
    private TextField nomeField;
    @FXML
    private TextField idadeField;
    @FXML
    private TextField sexoField;
    @FXML
    private TextField hemoglobinaField;
    @FXML
    private TextField hematocritoField;
    @FXML
    private TextField volumeCorporalField;
    @FXML
    private TextField hemoglobinaCorporalField;
    @FXML
    private TextField concentracaoHemoglobinaField;
    @FXML
    private TextField contagemGlobulosField;
    @FXML
    private TextField amplitudeDistribuicaoField;
    @FXML
    private TextField contagemGlobulosBrancosField;
    @FXML
    private TextField contagemNeutrofilosBastonetesField;
    @FXML
    private TextField contagemNeutrofilosSegmentadosField;
    @FXML
    private TextField contagemLinfocitosField;
    @FXML
    private TextField contagemMonocitosField;
    @FXML
    private TextField contagemEosinofilosField;
    @FXML
    private TextField contagemBasofilosField;
    @FXML
    private TextField contagemPlaquetasField;

    @FXML
    private TableView<Paciente> pacientesTable;
    @FXML
    private TableColumn<Paciente, String> nomeColumn;
    @FXML
    private TableColumn<Paciente, Integer> idadeColumn;
    @FXML
    private TableColumn<Paciente, String> sexoColumn;
    @FXML
    private TableColumn<Paciente, Double> hemoglobinaColumn;
    @FXML
    private TableColumn<Paciente, Double> hematocritoColumn;
    @FXML
    private TableColumn<Paciente, Double> volumeCorporalColumn;
    @FXML
    private TableColumn<Paciente, Double> hemoglobinaCorporalColumn;
    @FXML
    private TableColumn<Paciente, Double> concentracaoHemoglobinaColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemGlobulosColumn;
    @FXML
    private TableColumn<Paciente, Double> amplitudeDistribuicaoColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemGlobulosBrancosColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemNeutrofilosBastonetesColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemNeutrofilosSegmentadosColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemLinfocitosColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemMonocitosColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemEosinofilosColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemBasofilosColumn;
    @FXML
    private TableColumn<Paciente, Integer> contagemPlaquetasColumn;

    @FXML
    public void initialize() {
        nomeColumn.setCellValueFactory(new PropertyValueFactory<>("nome"));
        idadeColumn.setCellValueFactory(new PropertyValueFactory<>("idade"));
        sexoColumn.setCellValueFactory(new PropertyValueFactory<>("sexo"));
        hemoglobinaColumn.setCellValueFactory(new PropertyValueFactory<>("hemoglobina"));
        hematocritoColumn.setCellValueFactory(new PropertyValueFactory<>("hematocrito"));
        volumeCorporalColumn.setCellValueFactory(new PropertyValueFactory<>("volumeCorporal"));
        hemoglobinaCorporalColumn.setCellValueFactory(new PropertyValueFactory<>("hemoglobinaCorporal"));
        concentracaoHemoglobinaColumn.setCellValueFactory(new PropertyValueFactory<>("concentracaoHemoglobina"));
        contagemGlobulosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemGlobulos"));
        amplitudeDistribuicaoColumn.setCellValueFactory(new PropertyValueFactory<>("amplitudeDistribuicao"));
        contagemGlobulosBrancosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemGlobulosBrancos"));
        contagemNeutrofilosBastonetesColumn.setCellValueFactory(new PropertyValueFactory<>("contagemNeutrofilosBastonetes"));
        contagemNeutrofilosSegmentadosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemNeutrofilosSegmentados"));
        contagemLinfocitosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemLinfocitos"));
        contagemMonocitosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemMonocitos"));
        contagemEosinofilosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemEosinofilos"));
        contagemBasofilosColumn.setCellValueFactory(new PropertyValueFactory<>("contagemBasofilos"));
        contagemPlaquetasColumn.setCellValueFactory(new PropertyValueFactory<>("contagemPlaquetas"));

        carregarPacientes();
    }

    @FXML
    private void adicionarPaciente() {
        try {
            String nome = nomeField.getText();
            int idade = Integer.parseInt(idadeField.getText());
            String sexo = sexoField.getText().trim();
            if (sexo.length() != 1 || (!sexo.equalsIgnoreCase("M") && !sexo.equalsIgnoreCase("F"))) {
                throw new IllegalArgumentException("Sexo inválido. Use 'M' ou 'F'.");
            }

            double hemoglobina = Double.parseDouble(hemoglobinaField.getText());
            double hematocrito = Double.parseDouble(hematocritoField.getText());
            double volumeCorporal = Double.parseDouble(volumeCorporalField.getText());
            double hemoglobinaCorporal = Double.parseDouble(hemoglobinaCorporalField.getText());
            double concentracaoHemoglobina = Double.parseDouble(concentracaoHemoglobinaField.getText());
            int contagemGlobulos = Integer.parseInt(contagemGlobulosField.getText());
            double amplitudeDistribuicao = Double.parseDouble(amplitudeDistribuicaoField.getText());
            int contagemGlobulosBrancos = Integer.parseInt(contagemGlobulosBrancosField.getText());
            int contagemNeutrofilosBastonetes = Integer.parseInt(contagemNeutrofilosBastonetesField.getText());
            int contagemNeutrofilosSegmentados = Integer.parseInt(contagemNeutrofilosSegmentadosField.getText());
            int contagemLinfocitos = Integer.parseInt(contagemLinfocitosField.getText());
            int contagemMonocitos = Integer.parseInt(contagemMonocitosField.getText());
            int contagemEosinofilos = Integer.parseInt(contagemEosinofilosField.getText());
            int contagemBasofilos = Integer.parseInt(contagemBasofilosField.getText());
            int contagemPlaquetas = Integer.parseInt(contagemPlaquetasField.getText());

            Paciente paciente = new Paciente(nome, idade, sexo, hemoglobina, hematocrito, volumeCorporal,
                                             hemoglobinaCorporal, concentracaoHemoglobina, contagemGlobulos,
                                             amplitudeDistribuicao, contagemGlobulosBrancos, contagemNeutrofilosBastonetes,
                                             contagemNeutrofilosSegmentados, contagemLinfocitos, contagemMonocitos,
                                             contagemEosinofilos, contagemBasofilos, contagemPlaquetas);

            // Adiciona o paciente à base de dados e à tabela
            // database.addPaciente(paciente); // Descomente quando implementar a base de dados

            pacientesTable.getItems().add(paciente);
            limparCampos();
        } catch (NumberFormatException e) {
            exibirAlerta(AlertType.ERROR, "Entrada inválida", "Por favor, insira valores numéricos válidos.");
        } catch (IllegalArgumentException e) {
            exibirAlerta(AlertType.ERROR, "Erro de entrada", e.getMessage());
        } catch (Exception e) {
            exibirAlerta(AlertType.ERROR, "Erro inesperado", "Ocorreu um erro ao adicionar o paciente.");
        }
    }

    private void limparCampos() {
        nomeField.clear();
        idadeField.clear();
        sexoField.clear();
        hemoglobinaField.clear();
        hematocritoField.clear();
        volumeCorporalField.clear();
        hemoglobinaCorporalField.clear();
        concentracaoHemoglobinaField.clear();
        contagemGlobulosField.clear();
        amplitudeDistribuicaoField.clear();
        contagemGlobulosBrancosField.clear();
        contagemNeutrofilosBastonetesField.clear();
        contagemNeutrofilosSegmentadosField.clear();
        contagemLinfocitosField.clear();
        contagemMonocitosField.clear();
        contagemEosinofilosField.clear();
        contagemBasofilosField.clear();
        contagemPlaquetasField.clear();
    }

    private void exibirAlerta(AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }

    private void carregarPacientes() {
        try {
            // Supondo que exista um pacienteRepository
            for (Paciente paciente : pacienteRepository.obterTodosPacientes()) {
                pacientesTable.getItems().add(paciente);
            }
        } catch (Exception e) {
            exibirAlerta(AlertType.ERROR, "Erro ao carregar pacientes", "Não foi possível carregar a lista de pacientes.");
        }
    }
}
